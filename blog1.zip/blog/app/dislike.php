<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dislike extends Model
{
    //
}
